#Simple Crypto Library

A tiny crypto library, modified from boringssl source code, support AES/DES/MD5/SHA1/SHA256/SHA512/Base64, ndk-build ready for Android project.

created at 2016.01.16, based on boringssl source [0b553eb53126906d72928fdbb5db4506af1663fb](https://boringssl.googlesource.com/boringssl/+/0b553eb53126906d72928fdbb5db4506af1663fb)
