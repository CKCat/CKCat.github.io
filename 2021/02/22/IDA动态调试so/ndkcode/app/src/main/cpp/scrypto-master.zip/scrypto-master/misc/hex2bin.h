#ifndef HEX2BIN_H
#define HEX2BIN_H

char * bin2hex(unsigned char *bin, char *hex, int len);
unsigned char * hex2bin(char *hex, unsigned char *bin, int iLen, int *oLen);

#endif
